#!/bin/bash

# Linux System Breaker Script for Educational Purposes
# This script intentionally breaks various system components 
# to provide students with troubleshooting experience

if [ "$(id -u)" -ne 0 ]; then
    echo "This script must be run as root"
    exit 1
fi

# Randomly select a scenario (1-4)
SCENARIO=$((RANDOM % 4 + 1))

case "$SCENARIO" in
    1)

        # Corrupt network interface configuration (Debian/Ubuntu style)
        if [ -d /etc/network ]; then
            echo "auto eth0" > /etc/network/interfaces
            echo "iface eth0 inet sttic" >> /etc/network/interfaces
            echo "address 192.168.1.500" >> /etc/network/interfaces
            echo "netmask 255.255.255.256" >> /etc/network/interfaces
            echo "gateway 192.168.1" >> /etc/network/interfaces
        fi

        # Break netplan configuration (Ubuntu 18.04+)
        if [ -d /etc/netplan ]; then
            cat > /etc/netplan/99-broken.yaml << 'EOF'
network:
  version: 2
  renderer: networkd
  ethernets:
    eth0:
      dhcp4: no
      addresses: [192.168.1.500/24]
      gateway4: 192.168.1
      nameservers:
        addresses: [999.999.999.999]
EOF
        fi

        # Break DNS resolution
        echo "nameserver 999.999.999.999" > /etc/resolv.conf
        chmod 444 /etc/resolv.conf

        # Mess up routing table
        ip route del default 2>/dev/null || true
        ip route add default via 192.168.1.999 2>/dev/null || true
        ;;

    2)
        # Corrupt GRUB configuration
        if [ -f /boot/grub/grub.cfg ]; then
            sed -i 's/vmlinuz/vmlinux/g' /boot/grub/grub.cfg
            sed -i 's/root=UUID=/root=UUID=broken-/g' /boot/grub/grub.cfg
        fi
        
        # Break fstab
        echo "/dev/sda99 /important ext4 defaults 0 0" >> /etc/fstab
        sed -i 's/errors=remount-ro/errors=panic/g' /etc/fstab
        ;;

    3)
        # Remove execute permission from critical directories
        chmod 644 /bin/ls
        chmod 644 /bin/cat
        chmod 600 /etc/passwd
        
        # Change ownership of important files
        chown nobody:nogroup /etc/shadow
        chown 1000:1000 /etc/sudoers
        chmod 777 /etc/sudoers
        
        # Break SSH permissions
        chmod 777 /etc/ssh/sshd_config
        chmod 777 ~/.ssh/ 2>/dev/null || true
        ;;

    4)
        # Fill up disk space
        dd if=/dev/zero of=/var/log/bigfile bs=1M count=1000 2>/dev/null || true
        dd if=/dev/zero of=/tmp/hugefile bs=1M count=500 2>/dev/null || true
        
        # Create filesystem corruption simulation
        touch /forcefsck
        
        # Break log rotation
        echo "invalid content" > /etc/logrotate.conf
        ;;
esac

echo "Setup complete. Begin troubleshooting."